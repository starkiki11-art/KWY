package com.family.barcodebattle

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class Fighter(val code:String,val name:String,val rarity:String,val element:String,val avatar:String,val hp:Int,val atk:Int,val def:Int,val magic:Int,val agi:Int,val str:Int,val luck:Int)
enum class Action { ATTACK, DEFEND, SPECIAL, ITEM }
data class BattleState(var hp:Int,var special:Int=0,var items:Int=2)

class MainActivity: AppCompatActivity() {
    private var p1:Fighter?=null; private var p2:Fighter?=null; private var scanFor=1
    private val scanner=registerForActivityResult(ScanContract()){ r -> r.contents?.let { if(scanFor==1)p1=makeFighter(it) else p2=makeFighter(it); showSetup() } }
    override fun onCreate(b:Bundle?){ super.onCreate(b); requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE; window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN); showSetup() }

    private fun showSetup(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(40,24,40,24); setBackgroundColor(Color.rgb(8,18,32))}
        fun tv(t:String,sz:Float)=TextView(this).apply{text=t;textSize=sz;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(8,10,8,10)}
        root.addView(tv("⚔  BARCODE BATTLE FOLD  ⚔",30f))
        root.addView(tv("바코드를 스캔해 나만의 전사를 소환하세요",16f))
        val cards=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        fun card(n:Int,f:Fighter?)=Button(this).apply{
            text=if(f==null) "${n}P\n📷 바코드 스캔" else "${n}P  ${f.avatar} ${f.name}\n${f.rarity} · ${f.element}\nHP ${f.hp}  ⚔${f.atk}  🛡${f.def}"
            textSize=17f; minWidth=430; minHeight=150; setOnClickListener{scanFor=n;scan()}
        }
        cards.addView(card(1,p1)); cards.addView(Space(this),LinearLayout.LayoutParams(28,1)); cards.addView(card(2,p2)); root.addView(cards)
        val start=Button(this).apply{text="⚔️  대결 시작";textSize=20f;isEnabled=p1!=null&&p2!=null;setOnClickListener{startBattle()}}
        root.addView(start,LinearLayout.LayoutParams(520,100).apply{topMargin=18})
        root.addView(tv("같은 바코드 = 항상 같은 캐릭터 · 능력치 · 속성",13f))
        setContentView(root)
    }
    private fun scan(){scanner.launch(ScanOptions().setPrompt(if(scanFor==1)"1P 상품 바코드/QR 스캔" else "2P 상품 바코드/QR 스캔").setBeepEnabled(true).setOrientationLocked(false))}
    private fun startBattle(){setContentView(BattleView(this,p1!!,p2!!){showSetup()})}

    private fun makeFighter(code:String):Fighter{
        val hash=MessageDigest.getInstance("SHA-256").digest(("BARCODE-BATTLE-FOLD-v3|$code").toByteArray())
        val seed=hash.take(8).fold(0L){a,v->a*257+(v.toInt() and 255)}; val r=Random(seed); val roll=r.nextInt(1000)
        val rarity=when{roll<5->"신화";roll<25->"전설";roll<100->"영웅";roll<280->"희귀";roll<600->"고급";else->"일반"}
        val bonus=mapOf("일반" to 0,"고급" to 4,"희귀" to 9,"영웅" to 14,"전설" to 20,"신화" to 27)[rarity]!!
        val pre=arrayOf("강철","번개","화염","빙결","그림자","태양","폭풍","대지","별빛","황금","심연","수정")
        val job=arrayOf("기사","마도사","닌자","수호자","용사","사냥꾼","드루이드","검투사","정령사","용기사","골렘","야수")
        val avatars=arrayOf("🧙‍♂️","🧛","🥷","🤖","👹","👺","🐲","🦁","🐺","🦊","🦅","🦂","🦖","🗿","👾","🧚","🧝","🐉","🦍","🐯","🦄","🧌","🦹","🧞")
        val elements=arrayOf("🔥 불","💧 물","🌿 자연","⚡ 번개","❄️ 얼음","✨ 빛","🌑 어둠")
        fun stat()=r.nextInt(42,86)+bonus
        return Fighter(code,pre[r.nextInt(pre.size)]+" "+job[r.nextInt(job.size)],rarity,elements[r.nextInt(elements.size)],avatars[r.nextInt(avatars.size)],1200+r.nextInt(0,501)+bonus*10,stat(),stat(),stat(),stat(),stat(),r.nextInt(15,91))
    }
}

class BattleView(ctx:Context, private val f1:Fighter, private val f2:Fighter, private val quit:()->Unit):View(ctx){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG); private val s1=BattleState(f1.hp); private val s2=BattleState(f2.hp)
    private var a1:Action?=null; private var a2:Action?=null; private var turn=1; private var log="서로 행동을 선택하세요!"; private var gameOver=false
    private val rnd=Random(System.nanoTime()); private val actions=listOf(Action.ATTACK,Action.DEFEND,Action.SPECIAL,Action.ITEM)
    init{setLayerType(LAYER_TYPE_SOFTWARE,null);isFocusable=true}
    override fun onDraw(c:Canvas){super.onDraw(c);val w=width.toFloat();val h=height.toFloat();drawHalf(c,f2,s2,true,0f,0f,w,h/2);drawHalf(c,f1,s1,false,0f,h/2,w,h/2);drawDivider(c,w,h);drawCenter(c,w,h)}

    private fun drawHalf(c:Canvas,f:Fighter,st:BattleState,top:Boolean,x:Float,y:Float,w:Float,h:Float){
        c.save();if(top)c.rotate(180f,w/2,y+h/2)
        // layered fantasy arena background
        val bg=LinearGradient(0f,y,0f,y+h, if(top)Color.rgb(86,24,39) else Color.rgb(18,91,155), if(top)Color.rgb(28,10,22) else Color.rgb(4,38,76),Shader.TileMode.CLAMP);p.shader=bg;c.drawRect(x,y,w,y+h,p);p.shader=null
        p.color=Color.argb(55,255,220,130);c.drawCircle(w*.52f,y+h*.58f,h*.34f,p)
        p.color=Color.argb(90,10,28,24);for(i in 0..8){val xx=i*w/8;c.drawRect(xx,y+h*.74f,xx+w*.07f,y+h,p)}
        // player info glass card
        val info=RectF(22f,y+18f,w*.38f,y+h*.35f);p.color=Color.argb(210,5,20,38);p.setShadowLayer(12f,0f,5f,Color.argb(120,0,0,0));c.drawRoundRect(info,22f,22f,p);p.clearShadowLayer()
        text(c,if(top)"2P" else "1P",42f,y+55f,30f,if(top)Color.rgb(255,105,125) else Color.rgb(74,190,255),true)
        text(c,"${f.avatar}  ${f.name}",115f,y+54f,24f,Color.WHITE,true);text(c,"${f.rarity} · ${f.element}",115f,y+84f,15f,Color.rgb(235,235,235))
        text(c,"HP  ${st.hp} / ${f.hp}",42f,y+116f,16f,Color.WHITE,true);bar(c,42f,y+128f,w*.31f,18f,st.hp.toFloat()/f.hp)
        text(c,"⚔ ${f.atk}   🛡 ${f.def}   🔮 ${f.magic}   💨 ${f.agi}",42f,y+170f,16f,Color.WHITE)
        // big fighter + elemental aura
        val cx=w*.55f;val cy=y+h*.56f;p.color=elementColor(f.element,55);c.drawCircle(cx,cy,h*.27f,p);text(c,f.avatar,cx,cy+h*.12f,min(142f,h*.42f),Color.WHITE,false,true)
        // barcode card
        val card=RectF(w*.75f,y+h*.37f,w*.96f,y+h*.72f);p.color=Color.rgb(250,245,228);c.drawRoundRect(card,18f,18f,p);drawBarcode(c,f.code,card.left+18,card.top+18,card.width()-36,card.height()*.46f);text(c,f.name,card.centerX(),card.bottom-20,14f,Color.rgb(30,25,22),true,true)
        // buttons
        val by=y+h-76;val gap=10f;val bw=(w-gap*5)/4;for(i in 0..3){val l=gap+i*(bw+gap);val selected=(if(top)a2 else a1)==actions[i];val base=when(i){0->Color.rgb(232,62,45);1->Color.rgb(42,115,235);2->Color.rgb(176,48,224);else->Color.rgb(37,174,80)};p.color=if(selected)lighten(base) else base;p.setShadowLayer(if(selected)18f else 7f,0f,4f,Color.argb(130,0,0,0));c.drawRoundRect(l,by,l+bw,y+h-10,18f,18f,p);p.clearShadowLayer();val label=when(i){0->"⚔  공격";1->"🛡  방어";2->"✦  필살기 ${st.special}%";else->"🧪  아이템 ${st.items}"};text(c,label,l+bw/2,by+42,18f,Color.WHITE,true,true)}
        c.restore()
    }
    private fun drawDivider(c:Canvas,w:Float,h:Float){p.color=Color.rgb(255,184,45);c.drawRect(0f,h/2-3,w,h/2+3,p)}
    private fun drawCenter(c:Canvas,w:Float,h:Float){val box=RectF(w*.37f,h*.445f,w*.63f,h*.555f);p.color=Color.argb(242,8,18,36);p.setShadowLayer(16f,0f,4f,Color.BLACK);c.drawRoundRect(box,20f,20f,p);p.clearShadowLayer();p.style=Paint.Style.STROKE;p.strokeWidth=4f;p.color=Color.rgb(255,181,55);c.drawRoundRect(box,20f,20f,p);p.style=Paint.Style.FILL;text(c,if(gameOver)log else "TURN $turn",w/2,h/2-2,22f,Color.rgb(255,190,60),true,true);if(!gameOver)text(c,log,w/2,h/2+24,12f,Color.WHITE,false,true) else text(c,"가운데를 눌러 새 대결",w/2,h/2+24,12f,Color.WHITE,false,true)}
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP)return true;if(gameOver){quit();return true};val half=height/2f;val top=e.y<half;val localY=if(top)half-e.y else e.y-half;if(localY<half-95)return true;val idx=(e.x/(width/4f)).toInt().coerceIn(0,3);val act=actions[idx];if(top)a2=act else a1=act;if(a1!=null&&a2!=null)resolve();invalidate();return true}
    private fun resolve(){val x=a1!!;val y=a2!!;val first1=f1.agi+rnd.nextInt(21)>=f2.agi+rnd.nextInt(21);var msg="";fun hit(att:Fighter,asx:BattleState,act:Action,def:Fighter,ds:BattleState,dact:Action):String{if(ds.hp<=0)return "";return when(act){Action.DEFEND->{asx.special=min(100,asx.special+18);"${att.name} 방어!"};Action.ITEM->{if(asx.items>0){val heal=min(att.hp-asx.hp,220+rnd.nextInt(101));asx.hp+=heal;asx.items--;"${att.name} +$heal HP"}else "아이템 없음"};Action.SPECIAL->{if(asx.special>=100){asx.special=0;damage(att,def,ds,dact,true)}else{asx.special=min(100,asx.special+12);"필살 게이지 충전"}};Action.ATTACK->{asx.special=min(100,asx.special+22);damage(att,def,ds,dact,false)}}};if(first1){msg+=hit(f1,s1,x,f2,s2,y);if(s2.hp>0)msg+="  •  "+hit(f2,s2,y,f1,s1,x)}else{msg+=hit(f2,s2,y,f1,s1,x);if(s1.hp>0)msg+="  •  "+hit(f1,s1,x,f2,s2,y)};log=msg;turn++;a1=null;a2=null;if(s1.hp<=0||s2.hp<=0){gameOver=true;log=if(s1.hp<=0)"🏆 2P 승리!" else "🏆 1P 승리!"}}
    private fun damage(a:Fighter,d:Fighter,ds:BattleState,da:Action,special:Boolean):String{val evade=!special&&rnd.nextInt(100)<max(2,(d.agi-a.agi/2)/18);if(evade)return "${d.name} 회피!";var raw=if(special)(a.magic*2.1+a.str*.5-d.def*.35).toInt() else (a.atk+a.str*.45-d.def*.58).toInt();raw=max(if(special)100 else 35,raw+rnd.nextInt(-12,13));if(da==Action.DEFEND)raw=(raw*.38).toInt();val crit=rnd.nextInt(100)<5+a.luck/12;if(crit)raw=(raw*1.55).toInt();ds.hp=max(0,ds.hp-raw);return "${if(special)"필살" else "공격"} -$raw${if(crit)" 치명타!" else ""}"}
    private fun drawBarcode(c:Canvas,code:String,x:Float,y:Float,w:Float,h:Float){val bytes=MessageDigest.getInstance("MD5").digest(code.toByteArray());var xx=x;p.color=Color.BLACK;for(i in 0..55){val wide=((bytes[i%bytes.size].toInt() shr (i%7)) and 1)==1;val bw=if(wide)w/70f else w/120f;if(i%2==0)c.drawRect(xx,y,xx+bw,y+h,p);xx+=bw+1.5f;if(xx>x+w)break}}
    private fun elementColor(e:String,a:Int)=when{e.contains("불")->Color.argb(a,255,70,20);e.contains("물")->Color.argb(a,40,160,255);e.contains("자연")->Color.argb(a,60,220,80);e.contains("번개")->Color.argb(a,255,220,40);e.contains("얼음")->Color.argb(a,120,225,255);e.contains("빛")->Color.argb(a,255,245,180);else->Color.argb(a,160,70,230)}
    private fun lighten(c:Int)=Color.rgb(min(255,Color.red(c)+45),min(255,Color.green(c)+45),min(255,Color.blue(c)+45))
    private fun bar(c:Canvas,x:Float,y:Float,w:Float,h:Float,r:Float){p.color=Color.rgb(25,30,36);c.drawRoundRect(x,y,x+w,y+h,h/2,h/2,p);p.color=when{r>.5f->Color.rgb(20,225,80);r>.25f->Color.rgb(255,185,20);else->Color.rgb(245,55,55)};c.drawRoundRect(x,y,x+w*r.coerceIn(0f,1f),y+h,h/2,h/2,p)}
    private fun text(c:Canvas,t:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean=false,center:Boolean=false){p.shader=null;p.style=Paint.Style.FILL;p.textSize=size;p.color=color;p.typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;p.textAlign=if(center)Paint.Align.CENTER else Paint.Align.LEFT;c.drawText(t,x,y,p)}
}
