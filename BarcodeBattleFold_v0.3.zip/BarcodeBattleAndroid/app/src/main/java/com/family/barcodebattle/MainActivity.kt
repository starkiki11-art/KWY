package com.family.barcodebattle

import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

data class Fighter(val code:String,val name:String,val rarity:String,val element:String,val avatar:String,val hp:Int,val atk:Int,val def:Int,val magic:Int,val agi:Int,val str:Int,val luck:Int)
enum class Action { ATTACK, DEFEND, SPECIAL, ITEM }
data class BattleState(var hp:Int,var special:Int=0,var items:Int=2)

class MainActivity: AppCompatActivity() {
    private var p1:Fighter?=null; private var p2:Fighter?=null; private var scanFor=1
    private lateinit var status:TextView
    private val scanner=registerForActivityResult(ScanContract()){ r -> r.contents?.let { if(scanFor==1)p1=makeFighter(it) else p2=makeFighter(it); showSetup() } }
    override fun onCreate(b:Bundle?){ super.onCreate(b); requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE; showSetup() }

    private fun showSetup(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(28,18,28,18); setBackgroundColor(Color.rgb(12,18,30))}
        fun tv(t:String,sz:Float)=TextView(this).apply{text=t;textSize=sz;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setPadding(8,8,8,8)}
        root.addView(tv("BARCODE BATTLE • FOLD 1 VS 1",28f))
        status=tv("1P  ${p1?.let{"${it.avatar} ${it.name} / ${it.rarity} / ${it.element}"}?:"캐릭터 없음"}\n\n2P  ${p2?.let{"${it.avatar} ${it.name} / ${it.rarity} / ${it.element}"}?:"캐릭터 없음"}",18f); root.addView(status)
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
        val b1=Button(this).apply{text="📷 1P 바코드 스캔";setOnClickListener{scanFor=1;scan()}}
        val b2=Button(this).apply{text="📷 2P 바코드 스캔";setOnClickListener{scanFor=2;scan()}}
        val start=Button(this).apply{text="⚔️ 대결 시작";isEnabled=p1!=null&&p2!=null;setOnClickListener{startBattle()}}
        row.addView(b1);row.addView(b2);row.addView(start);root.addView(row)
        root.addView(tv("같은 바코드는 항상 같은 캐릭터·능력치·속성이 나옵니다. 전투 중에는 서로의 선택이 숨겨집니다.",14f))
        setContentView(root)
    }
    private fun scan(){ scanner.launch(ScanOptions().setPrompt(if(scanFor==1)"1P 상품 바코드/QR 스캔" else "2P 상품 바코드/QR 스캔").setBeepEnabled(true).setOrientationLocked(false)) }
    private fun startBattle(){ setContentView(BattleView(this,p1!!,p2!!){showSetup()}) }

    private fun makeFighter(code:String):Fighter{
        val hash=MessageDigest.getInstance("SHA-256").digest(("BARCODE-BATTLE-FOLD-v3|$code").toByteArray())
        val seed=hash.take(8).fold(0L){a,v->a*257+(v.toInt() and 255)}; val r=Random(seed); val roll=r.nextInt(1000)
        val rarity=when{roll<5->"신화";roll<25->"전설";roll<100->"영웅";roll<280->"희귀";roll<600->"고급";else->"일반"}
        val bonus=mapOf("일반" to 0,"고급" to 4,"희귀" to 9,"영웅" to 14,"전설" to 20,"신화" to 27)[rarity]!!
        val pre=arrayOf("강철","번개","화염","빙결","그림자","태양","폭풍","대지","별빛","황금","심연","수정")
        val job=arrayOf("기사","마도사","닌자","수호자","용사","사냥꾼","드루이드","검투사","정령사","용기사","골렘","야수")
        val avatars=arrayOf("🧙","🧛","🥷","🤖","👹","👺","🐲","🦁","🐺","🦊","🦅","🦂","🦖","🗿","👾","🧚","🧜","🦹","🧝","🐉","🦈","🦍","🐯","🦄")
        val elements=arrayOf("🔥 불","💧 물","🌿 자연","⚡ 번개","❄️ 얼음","✨ 빛","🌑 어둠")
        fun stat()=r.nextInt(42,86)+bonus
        return Fighter(code,pre[r.nextInt(pre.size)]+" "+job[r.nextInt(job.size)],rarity,elements[r.nextInt(elements.size)],avatars[r.nextInt(avatars.size)],1200+r.nextInt(0,501)+bonus*10,stat(),stat(),stat(),stat(),stat(),r.nextInt(15,91))
    }
}

class BattleView(ctx:Context, private val f1:Fighter, private val f2:Fighter, private val quit:()->Unit):View(ctx){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG); private val s1=BattleState(f1.hp); private val s2=BattleState(f2.hp)
    private var a1:Action?=null;private var a2:Action?=null;private var turn=1;private var log="서로 행동을 선택하세요";private var gameOver=false
    private val rnd=Random(System.nanoTime()); private val actions=listOf(Action.ATTACK,Action.DEFEND,Action.SPECIAL,Action.ITEM)
    init{setBackgroundColor(Color.rgb(8,13,23));isFocusable=true}
    override fun onDraw(c:Canvas){super.onDraw(c); val w=width.toFloat();val h=height.toFloat(); drawHalf(c,f2,s2,true,0f,0f,w,h/2);drawHalf(c,f1,s1,false,0f,h/2,w,h/2);p.color=Color.rgb(255,171,32);c.drawRect(0f,h/2-3,w,h/2+3,p);drawCenter(c)}
    private fun drawHalf(c:Canvas,f:Fighter,st:BattleState,top:Boolean,x:Float,y:Float,w:Float,h:Float){
        c.save(); if(top){c.rotate(180f,w/2,y+h/2)}
        p.color=if(top)Color.rgb(48,15,25) else Color.rgb(12,38,70);c.drawRect(x,y,w,y+h,p)
        text(c,if(top)"2P" else "1P",x+28,y+42,30f,Color.WHITE,true); text(c,"${f.avatar}  ${f.name}",x+105,y+42,25f,Color.WHITE,true);text(c,"${f.rarity}  ${f.element}",x+105,y+72,16f,Color.LTGRAY,false)
        text(c,f.avatar,w*.18f,y+h*.58f,min(96f,h*.35f),Color.WHITE,false)
        text(c,"HP ${st.hp} / ${f.hp}",w*.32f,y+42,20f,Color.WHITE,true);bar(c,w*.32f,y+55,w*.34f,18f,st.hp.toFloat()/f.hp)
        text(c,"⚔ ${f.atk}   🛡 ${f.def}   🔮 ${f.magic}   💨 ${f.agi}",w*.32f,y+98,18f,Color.WHITE,false)
        text(c,"필살 ${st.special}/100   아이템 ${st.items}",w*.32f,y+128,15f,Color.LTGRAY,false)
        val by=y+h-68; val bw=w/4f-12; for(i in 0..3){val l=8+i*w/4f; val selected=(if(top)a2 else a1)==actions[i];p.color=if(selected)Color.rgb(255,193,7) else when(i){0->Color.rgb(210,55,45);1->Color.rgb(25,105,210);2->Color.rgb(120,55,190);else->Color.rgb(30,150,75)};c.drawRoundRect(l,by,l+bw,y+h-8,16f,16f,p); val label=when(i){0->"⚔ 공격";1->"🛡 방어";2->"✦ 필살기";else->"● 아이템"};text(c,label,l+bw/2,by+39,19f,Color.WHITE,true,true)}
        c.restore()
    }
    private fun drawCenter(c:Canvas){ val w=width.toFloat();val h=height.toFloat();p.color=Color.argb(220,5,10,18);c.drawRoundRect(w*.37f,h*.43f,w*.63f,h*.57f,18f,18f,p);text(c,if(gameOver)log else "TURN $turn  •  $log",w/2,h/2+8,17f,Color.WHITE,true,true); if(gameOver){text(c,"화면 가운데를 눌러 새 대결",w/2,h/2+34,13f,Color.YELLOW,false,true)} }
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action!=MotionEvent.ACTION_UP)return true;if(gameOver){quit();return true};val top=e.y<height/2f;val localY=if(top) height/2f-e.y else e.y-height/2f;if(localY < height/2f-85)return true; val idx=(e.x/(width/4f)).toInt().coerceIn(0,3);val act=actions[idx];if(top)a2=act else a1=act;if(a1!=null&&a2!=null)resolve();invalidate();return true}
    private fun resolve(){val x=a1!!;val y=a2!!; val first1=f1.agi+rnd.nextInt(21)>=f2.agi+rnd.nextInt(21);var msg="";fun hit(att:Fighter,asx:BattleState,act:Action,def:Fighter,ds:BattleState,dact:Action):String{if(ds.hp<=0)return "";return when(act){Action.DEFEND->{asx.special=min(100,asx.special+18);"${att.name} 방어 준비"};Action.ITEM->{if(asx.items>0){val heal=min(att.hp-asx.hp,220+rnd.nextInt(101));asx.hp+=heal;asx.items--;"${att.name} HP +$heal"}else "${att.name} 아이템 없음"};Action.SPECIAL->{if(asx.special>=100){asx.special=0;damage(att,asx,def,ds,dact,true)}else {asx.special=min(100,asx.special+12);"${att.name} 필살 게이지 부족"}};Action.ATTACK->{asx.special=min(100,asx.special+22);damage(att,asx,def,ds,dact,false)}}}
        if(first1){msg+=hit(f1,s1,x,f2,s2,y);if(s2.hp>0)msg+="  |  "+hit(f2,s2,y,f1,s1,x)}else{msg+=hit(f2,s2,y,f1,s1,x);if(s1.hp>0)msg+="  |  "+hit(f1,s1,x,f2,s2,y)}
        log=msg;turn++;a1=null;a2=null;if(s1.hp<=0||s2.hp<=0){gameOver=true;log=if(s1.hp<=0)"🏆 2P ${f2.name} 승리!" else "🏆 1P ${f1.name} 승리!"}}
    private fun damage(a:Fighter,asx:BattleState,d:Fighter,ds:BattleState,da:Action,special:Boolean):String{val evade=!special&&rnd.nextInt(100)<max(2,(d.agi-a.agi/2)/18);if(evade)return "${d.name} 회피!";var raw=if(special)(a.magic*2.1+a.str*.5-d.def*.35).toInt() else (a.atk+a.str*.45-d.def*.58).toInt();raw=max(if(special)100 else 35,raw+rnd.nextInt(-12,13));if(da==Action.DEFEND)raw=(raw*.38).toInt();val crit=rnd.nextInt(100)<5+a.luck/12;if(crit)raw=(raw*1.55).toInt();ds.hp=max(0,ds.hp-raw);return "${a.name} ${if(special)"필살" else "공격"} -$raw${if(crit)" 치명타!" else ""}${if(da==Action.DEFEND)" (방어)" else ""}"}
    private fun bar(c:Canvas,x:Float,y:Float,w:Float,h:Float,r:Float){p.color=Color.DKGRAY;c.drawRoundRect(x,y,x+w,y+h,h/2,h/2,p);p.color=when{r>.5f->Color.rgb(30,210,85);r>.25f->Color.rgb(255,180,20);else->Color.RED};c.drawRoundRect(x,y,x+w*r.coerceIn(0f,1f),y+h,h/2,h/2,p)}
    private fun text(c:Canvas,t:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean=false,center:Boolean=false){p.textSize=size;p.color=color;p.typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;p.textAlign=if(center)Paint.Align.CENTER else Paint.Align.LEFT;c.drawText(t,x,y,p)}
}
